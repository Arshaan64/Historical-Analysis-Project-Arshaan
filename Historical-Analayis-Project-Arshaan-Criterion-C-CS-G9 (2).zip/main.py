
def login():
  un = input("Please enter a username that is greater than 8 characters in length: ")
  pw = input("Please enter a password that is greater than 8 characters in length: ")

  if len(un) >= 8 and len(pw) >= 8:
      print("Login successful! Welcome to Arshaan's historical analysis application! How may it help you today?")
      return True
  else:
      print("Log in unsuccessful. Please try again.")
      return False

def signup():
  un = input("Please enter a username that is greater than 8 characters in length: ")
  pw = input("Please enter a password that is greater than 8 characters in length: ")
  re = input("Please enter an email address that follows this format: username@domain.com: ")
  pn = input("Please enter a phone number that is between 7 and 15 characters in length: ")

  # Simple example check for email using '@' and '.com' presence
  is_email_valid = '@' in re and re.endswith('.com')

  if len(un) >= 8 and len(pw) >= 8 and is_email_valid and 7 <= len(pn) <= 15:
      print("Sign up successful! Welcome to Arshaan's historical analysis application! How may it help you today?")
      return True
  else:
      print("Please re-enter sign-up details and try again.")
      return False

def main():
  while True:
      print("Welcome! To proceed further, you must log in or sign up to this application.")
      print("Would you like to log in or sign up? Note- if you are using this application for the first time, you must sign up.")
      choice = input().strip().lower()

      if choice == "log in":
          if login():
              break  # Exit loop if login is successful
      elif choice == "sign up":
          if signup():
              break  # Exit loop if signup is successful
      else:
          print("Invalid choice. Please enter 'log in' or 'sign up'.")

# Call the main function to run the application
main()
                
      
print("To learn more about a historical event or time period, either search for an event or select an event from the list below. Would you like to search or select?")

choice=input()
if choice=="search":
  print("Please enter the name of the event or time period you would like to learn more about.  Note- as this application is targeted towards IGCSE students and historians who specialise in 20th century history, the events or time periods included will be from the 20th century.")
def search():
    while True:
        # This should only be printed once per search invocation
        print("Please enter the name of the event or time period you would like to learn more about. Note- as this application is targeted towards IGCSE students and historians who specialise in 20th-century history, the events or time periods included will be from the 20th century.")
event = input("Event name: ").strip().lower()
if event in ["the russo-japanese war", "russo-japanese war", "russo japanese war", "the russo-japanese war of 1904-1905", "russia vs japan", "1904-1905"]:
        print("Here are some general facts about The Russo-Japanese War of 1904-1905.")
        print("This historical occurrence was very significant and contributed greatly to 20th-century history as a whole.")
        print("This event was a major turning point in the 20th century and history during this time would have been incomplete and greatly different without its occurrence.")
        print("There were several deep-rooted causes, complex points, and positive and negative impacts in this event, and it is in accordance with the 20th century, which was a time for change, innovation, and conflict. One's knowledge of this event would be incomplete without considering the diverse perspectives and correlated variables linked to it.")
        print("Among the general facts listed above, there were several causes, correlated variables, unique occurrences, and impacts in the Russo-Japanese War of 1904-1905. The causes of this conflict include Russian expansionist policy for East Asia, as Russia had captured Port Arthur in Manchuria and went against its word to withdraw troops from Manchuria as well. The Japanese, who wanted to capture Manchuria themselves, were not keen on letting this happen, and as they had recently defeated China in the Sino-Japanese War, were motivated by a strong sense of nationalism—leading to a Japanese surprise attack on the Russian Pacific Fleet at Port Arthur. The result of this conflict was Japanese victory, and thus, this war marked the first time a major European power had been defeated by an Asian country, illustrating a turning point in the balance of power in East Asia, with Japan emerging as the most powerful nation in the region.")
        print("Moreover, Russia's defeat in this war convinced individuals in the country that the empire was failing and that there was a need for change and reform—through either an improved constitution or revolution. As a result, the 1905 revolution occurred in Russia, where the workers, the military, and peasants rose against Tsar (King) Nicholas II, the nobility, and the ruling class. However, many protesters were fired upon and massacred during Bloody Sunday, sparking further civil unrest that lasted until the final days of the Russian Empire.")
        print("In addition, this war hinted at Japan's imperial ambitions in Manchuria, which eventually developed into the Japanese invasion of Manchuria and China in the 1930s. The Japanese acted in this manner due to their territorial aims and also due to their pan-Asianist ideals. Japan's pan-Asianism was an ideology that outlined that as Japan was the first Asian country to develop, modernize, and catch up to the west, it had a moral obligation to rule and govern over other Asian countries to spread their knowledge. This is further reinforced by the fact that Japan invaded Korea in 1910 and attempted to invade China in 1936.")
        print("This war and the consequent Treaty of Portsmouth left relations between Russia and Japan strained, fostering tensions in the region. Nevertheless, it demonstrated how a European nation could be defeated by an Asian power through superior military strategy and technology, as the Japanese had overpowered the Russians with superior technology and warfare tactics. Two of the most significant battles at which the Japanese defeated the Russians were the Battle of Mukden and the Battle of Tshushima. In the ground battle of Mukden, the Japanese stormed the south of Mukden, forcing the Russians to retreat north. The Japanese lost 40,000 soldiers in this battle, while the Russians lost 60,000. Furthermore, the Japanese also overpowered the Russians at the naval Battle of Tshushima, in which Japanese ships were faster and better equipped than Russian ones, leading to the Japanese sinking Russian battleships and securing decisive victories.")


# else: print("Invalid choice. Please enter 'search' or 'select'.")    # Ensure necessary logic leads to defining `event` appropriately



# To test the search function individually, you can call it here:




     # To test the search function individually, you can call it here:
event=input(print("Please enter the name of the event or time period you would like to learn more about. Note- as this application" "is targeted towards IGCSE students and historians who specialise in 20th century history, the events will be from the 20th century:"))
if event in ["the great depression", "1929-1939", "great depression", "wall street crash"]:
 print("Here are some general facts about The Great Depression")
print("This historical occurrence was very significant and contributed greatly to 20th-century history as a whole.")
print("This event was a major turning point in the 20th century and history during this time would have been incomplete and greatly different without its occurrence.")
print("There were several deep-rooted causes, complex points, and positive and negative impacts in this event, and it is in accordance with the 20th century, which was a time for change, innovation, and conflict. One's knowledge of this event would be incomplete without considering the diverse perspectives and correlated variables linked to it.")
print("Among the general facts listed above, there were several causes, correlated variables, unique occurrences and impacts in the Great Depression of 1929-1933. One of the major causes of this event was the Wall Street Crash of 1929, where the stock market in the United States plummeted due to a combination of factors, including overproduction, speculation, and excessive credit. This led to a widespread economic panic and a domino effect of bank failures and business closures. The Depression lasted for a decade, and had a devastating impact on the global economy, with high rates of unemployment, poverty, and homelessness. It impacted countries outside of the United States as well as many states were reliant on American firms and businesses to participate in trade and make profitable deals.")
print("The Depression also had a significant impact on the political landscape, contributing to the rise of populist movements and the expansion of government intervention in the economy. In the United States, President Franklin Delano Roosevelt's New Deal programs aimed to provide relief to the unemployed, stimulate economic recovery, and reform the financial system. The Depression also played a role in the rise of fascism in Europe, as people sought strong leadership and solutions to economic hardship.")
print("The Great Depression also had a lasting impact on economic policy, as governments and international organizations adopted measures to prevent future economic crises. The Depression had a profound impact on society, leading to widespread social unrest, changes in cultural attitudes, and a growing awareness of social inequalities. It also led to the development of new economic theories and the establishment of new institutions to regulate the economy.")
print("The Great Depression was monumental in the failure of the League of Nations, as it contributed to why the international peacekeeping organisation did not possess the necessary military and economic resources to hold nations accountable for actions in violation of agreements and the League of Nations Covenant. This is the case as the Great Depression greatly restricted the amount of disposable income and the spending power of most nations, particularly states such as Great Britain and France- who were the most significant in the League and were two of the few permanent members. As a result, these nations and others were unable to support the League militarily or economically when Japan invaded Manchuria- which is explained in 'The Manchurian Crisis' section of this application, or when Italy invaded Abyssinia- which is explained in the 'Abyssinian Crisis' section of this application.")
print("To learn more about The Great Depression, you may refer to the Chatbot included in this application for helpful resources and MLA8 citations.")

event=input(print("Please enter the name of the event or time period you would like to learn more about. Note- as this application" "is targeted towards IGCSE students and historians who specialise in 20th century history, the events will be from the 20th century:"))
if event in ["world war i", "world war 1", "the great war", "the great war of 1914-1918", "1914-1918"]:
          print("This historical occurrence was very significant and contributed greatly to 20th-century history as a whole.")
print("This event was a major turning point in the 20th century and history during this time would have been incomplete and greatly different without its occurrence.")
print("There were several deep-rooted causes, complex points, and positive and negative impacts in this event, and it is in accordance with the 20th century, which was a time for change, innovation, and conflict. One's knowledge of this event would be incomplete without considering the diverse perspectives and correlated variables linked to it.")
print("Among the general facts listed above, there were several causes, correlated variables, unique occurrences and impacts in the First World War of 1914-1918. One of the major causes of the war was the assassination of Archduke Franz Ferdinand of Austria by a Serbian nationalist named Gavrilo Princip. The assassination created a chain reaction of diplomatic failures and military mobilisation, eventually leading to a large-scale conflict. The war involved a complex web of alliances, and quickly escalated to a global conflict that lasted for four years, and resulted in the deaths of millions of people.")
print("In addition, the war led to the collapse of several empires, including the Austro-Hungarian, Ottoman, Russian, and German empires. It also led to the rise of new nations, such as Czechoslovakia, Yugoslavia, and Poland, and had a profound impact on the geopolitical landscape of Europe.")
print("The war also saw the development of new technologies, such as tanks, airplanes, and poison gas, which had a significant impact on the course of the war and subsequent conflicts. The use of these technologies led to a massive loss of life and had a lasting impact on the way wars were fought.")
print("The war also led to the Treaty of Versailles, which imposed harsh penalties on Germany, including the loss of territory, reparations payments, and a limitation on its military. These penalties contributed to the rise of nationalism and resentment in Germany, which ultimately led to the rise of Adolf Hitler and the Nazi Party in the 1930s.")
print("The Treaty of Versailles also led to the rise of a new world order, with the United States emerging as a global power. The war also had a significant impact on the development of international organizations, such as the League of Nations, which was created to prevent future wars, although it failed to prevent the outbreak of World War II.")
print("To learn more about World War I, you may refer to the Chatbot included in this application for helpful resources and MLA8 citations.")

event=input(print("Please enter the name of the event or time period you would like to learn more about. Note- as this application" "is targeted towards IGCSE students and historians who specialise in 20th century history, the events will be from the 20th century:"))
if event in["world war ii", "world war 2", "the second world war", "1939-1945"]:
  print("Here are some general facts about World War II")
print("This historical occurrence was very significant and contributed greatly to 20th-century history as a whole.")
print("This event was a major turning point in the 20th century and history during this time would have been incomplete and greatly different without its occurrence.")
print("There were several deep-rooted causes, complex points, and positive and negative impacts in this event, and it is in accordance with the 20th century, which was a time for change, innovation, and conflict. One's knowledge of this event would be incomplete without considering the diverse perspectives and correlated variables linked to it.")
print("Among the general facts listed above, there were several causes, correlated variables, unique occurrences and impacts in World War II- the deadliest conflict in human history. The war was a global conflict that involved most of the world's countries, including all of the great powers, eventually forming two opposing military alliances: the Allies and the Axis. In a state of total war (meaning that nations fully committed themselves to the war effort and placed essentially all their hopes and resources on victory), directly involving more than 100 million personnel from more than 30 countries, the major participants threw their entire economic, industrial, and scientific capabilities behind the war effort, blurring the distinction between civilian and military resources. World War II was marked by 50 to 85 million fatalities, most of whom were civilians in the Soviet Union and China. Tens of millions of people died due to genocides (including the Holocaust), premeditated death from starvation, massacres, and disease.")
print("The major participants in World War II were the Axis powers, led by Nazi Germany, the Empire of Japan, and the Kingdom of Italy, and the Allies, originally led by the United Kingdom, the United States, the Soviet Union, the Republic of China, and later by many other countries.")
print("The war began on 1 September 1939 with the invasion of Poland by Germany and the subsequent declaration of war on Germany by France and the United Kingdom. Germany had invaded Poland as Adolf Hitler, along with other conservative nationalists in Germany, believed that the land taken away from Germany as per the Treaty of Versailles was rightfully theirs and should therefore be reclaimed from Poland. Hitler named his planned invasion of Poland 'Lebensraum'. The war in Europe ended on 8 May 1945 with the unconditional surrender of Nazi Germany to the Allies. The war in the Pacific ended on 2 September 1945 with the unconditional surrender of Japan to the Allies.")
print("World War II had a profound impact on the world. It led to the deaths of millions of people, the destruction of entire cities, and the displacement of millions more. The war also led to the rise of the United States and the Soviet Union as superpowers, the emergence of new international organizations such as the United Nations- which was created from old departments of the League of Nations, and the beginning of the Cold War- between the United States and the Soviet Union- the two above mentioned global superpowers. Although the United States had economic superiority, the Soviet Union was far larger and had comparable, if not superior military strength.")
print("To learn more about World War II, you may refer to the Chatbot included in this application for helpful resources and MLA8 citations.")
        # To test the search function individually, you can call it here:




        # To test the search function individually, you can call it here:
event=input(print("Please enter the name of the event or time period you would like to learn more about. Note- as this application" "is targeted towards IGCSE students and historians who specialise in 20th century history, the events will be from the 20th century:"))
if event in["the abyssinian crisis", "abyssinian crisis", "1934-1935", "walwal incident", "italian invasion of abyssinia"]: 
 print("Here are some general facts about The Abyssinian Crisis")
print("This historical occurrence was very significant and contributed greatly to 20th-century history as a whole.")
print("This event was a major turning point in the 20th century and history during this time would have been incomplete and greatly different without its occurrence.")
print("There were several deep-rooted causes, complex points, and positive and negative impacts in this event, and it is in accordance with the 20th century, which was a time for change, innovation, and conflict. One's knowledge of this event would be incomplete without considering the diverse perspectives and correlated variables linked to it.")
print("Among the general facts listed above, there were several causes, correlated variables, unique occurrences and impacts in the Abyssinian Crisis of 1934-1935. The Italian invasion of Abyssinia (Ethiopia) was a significant event in the lead-up to World War II, and a major failure of the League of Nations. It demonstrated that the League could not effectively enforce international law and prevent aggression when powerful nations were involved.")
print("The Italian invasion of Abyssinia was driven by Italian ambitions to expand its colonial empire and to assert its power in the Mediterranean and African regions. Italy had been humiliated by its defeat in the First World War and felt a need to restore its international prestige and status. Moreover, it had lost to Abyssinia in a conflict at the beginning of the 20th century, similar to how Russia had lost to Japan in the Russo-Japanese War of 1904-1905.")
print("The invasion began in 1935 after a border incident known as the Walwal Incident, in which Italian and Abyssinian troops clashed over a disputed territory. The Italians used this incident as a pretext to launch a full-scale invasion, despite the League of Nations condemning their actions.")
print("The Abyssinian Crisis had a number of significant consequences. It further weakened the League of Nations and emboldened other aggressor nations, such as Germany and Japan, to disregard international law and pursue their own expansionist goals. The crisis also highlighted the corruption within the League of Nations, as Britain and France- who held control over the Suez Canal (the easiest path from Europe to Africa), and could have very simply restricted Italy from its invasion, instead struck a secret deal with Benito Mussolini, in which the powers agreed to form an alliance and let Mussolini wage his war of aggression. This was due to the fact that Great Britain and France feared the new German leader, Adolf Hitler, who had left the League of Nations, and was rapidly re-arming Germany.")
print("The Abyssinian Crisis is considered to be one of the major turning points that led to World War II. It showed that the international community was unable to prevent aggression by powerful nations, and it contributed to the breakdown of the international order.")
print("To learn more about The Abyssinian Crisis, you may refer to the Chatbot included in this application for helpful resources and MLA8 citations.")
  #else: pass
print("Invalid event. Please enter a valid historical event.")

#def main():
event = input("Enter the event you want to learn about: ").strip().lower()
# get_event_information(event)

  # Call the main function to run the application
main()




 




  
  
 
def select():
        # Display initial instructions
        print("Please select the name of the historical event or time period you would like to learn more about.")
        print("Note: As this application is targeted towards IGCSE students and historians who specialize in 20th-century history, the events or time periods included will be from the 20th century.")
        print("Please choose from the following options:")
        print("The Russo-Japanese War")
        print("World War I")
        print("The Great Depression")
        print("The Manchurian Crisis")
        print("The Abyssinian Crisis")
        print("World War II")
    
choice=input()
if choice==select():
        print("Please select the name of the historical event or time period you would like to learn more about.")
        print("Note: As this application is targeted towards IGCSE students and historians who specialize in 20th-century history, the events or time periods included will be from the 20th century.")
        print("Please choose from the following options:")
        print("The Russo-Japanese War")
        print("World War I")
        print("The Great Depression")
        print("The Manchurian Crisis")
        print("The Abyssinian Crisis")
        print("World War II")

event=input("Please choose from the following options").strip().lower()
if event in ["The Russo-Japanese War"]:  # Code inside the if statement will run if the event is The Russo-Japanese War
      print("There were several causes, correlated variables, unique occurences and impacts in the Russo-Japanese War of 1904-1905. The causes of this conflict include Russian expansionist policy for East Asia, as Russia had captured Port Arthur in Manchuria, and went against its word to withdraw troops from Manchuria as well. The Japanese, who wanted to capture Manchuria themselves, were not keen on letting this happen, and as they had recently defeated China in the Sino-Japanese War, were motivated by a strong sense of nationalism- leading to a Japanese surprise attack on the Russian Pacific Fleet at Port Arthur. The result of this conflict was Japanese victory, and thus, this war marked the first time a major European power had been defeated by an Asian country, illustrating a turning point in the balance of power in East Asia- with Japan emerging as the most powerful nation in the region.")
      print("Moreover, Russia's defeat in this war convinced individuals in the country that the empire was failing, and that there was need for change and reform- through either an improved constitution or revolution. As a result, the 1905 revolution occurred in Russia, where the workers, the military, and peasants rose against Tsar (King), Nicholas II, the nobility, and the ruling class. However, many protesters were fired upon and massacred during Bloody Sunday, sparking further civil unrest that lasted until the final days of the Russian Empire. ")
      print("In addition, this war hinted at Japan's imperial ambitions in Manchuria, which eventually developed into the Japanese invasion of Manchuria and China in the 1930s. The Japanese acted in this manner due to their territorial aims and also due to their pan-asianist ideals. Japan's pan-asianism was an ideology that outlined that as Japan was the first Asian country to develop, modernise, and catch up to the west, it had a moral obligation to rule and govern over other Asian countries to spread their knowledge. This is further reinforced by the fact that Japan invaded Korea in 1910, and attempted to invade China in 1936.")
      print("This war and the consequent Treaty of Portsmouth left relations between Russia and Japan strained, fostering tensions in the region. Nevertheless, it demonstrated how a European nation could be defeated by an Asian power through superior military strategy and technology, as the Japanese had overpowered the Russians with superior  technology and warfare tactics. Two of the most significant battles at which the Japanese defeated the Russians were the Battle of Mukden, and the Battle of Tshushima. In the ground battle of Mukden,  the Japanese stormed the south of Mukden- forcing the Russians to retreat North. The Japanese lost 40,000 soldiers in this battle, while the Russians lost 60,000. Furthermore, the Japanese also overpowered the Russians at the naval Battle of Tshushima, in which Japanese ships were faster and better equipped    than Russian ones, leading to the Japanese sinking  two-thirds of the entire Russian fleet. This battle was a decisive victory in the war for the Japanese, and diminished any Russian hope of regainining their control over the region.") 
      print("To learn more about the Russo-Japanese War, you may refer to the Chatbot included in this application for helpful resources and MLA8 citations.")

if event in ["World War I"]:  # Code inside the if statement will run if the event is World War I
      print("There were several causes, correlated variables, unique occurences and impacts in World War I.  One of the major causes of the war was the assassination of Archduke Franz Ferdinand of Austria by a Serbian nationalist named Gavrilo Princip. The assassination created a chain reaction of diplomatic failures and military mobilisation, eventually leading to a large-scale conflict. The war involved a complex web of alliances, and quickly escalated to a global conflict that lasted for four years, and resulted in the deaths of millions of people.") 
      print("In addition, the war led to the collapse of several empires, including the Austro-Hungarian, Ottoman, Russian, and German empires. It also led to the rise of new nations, such as Czechoslovakia, Yugoslavia, and Poland, and had a profound impact on the geopolitical landscape of Europe. ")
      print("The war also saw the development of new technologies, such as tanks, airplanes, and poison gas, which had a significant impact on the course of the war and subsequent conflicts. The use of these technologies led to a massive loss of life and had a lasting impact on the way wars were fought. ")
      print("The war also led to the Treaty of Versailles, which imposed harsh penalties on Germany, including the loss of territory, reparations payments, and a limitation on its military. These penalties contributed to the rise of nationalism and resentment in Germany, which ultimately led to the rise of Adolf Hitler and the Nazi Party in the 1930s. ")
      print("The Treaty of Versailles also led to the rise of a new world order, with the United States emerging as a global economic and diplomatic power. The war also had a significant impact on the development of international organizations, such as the League of Nations, which was created to prevent future wars, although it failed to prevent the outbreak of World War II. ")
      print("To learn more about World War I, you may refer to the Chatbot included in this application for helpful resources and MLA8 citations.")

     
if event in ["The Great Depression"]:
          print("There were several causes, correlated variables, unique occurrences and impacts in the Great Depression of 1929-1933.  One of the major causes of this event was the Wall Street Crash of 1929, where the stock market in the United States plummeted due to a combination of factors, including overproduction, speculation, and excessive credit.  This led to a widespread economic panic and a domino effect of bank failures and business closures.  The Depression lasted for a decade, and had a devastating impact on the global economy, with high rates of unemployment, poverty, and homelessness. It impacted countries outside of the United States as well as many states were reliant on American firms and businesses to participate in trade and make profitable deals.")
          print("The Depression also had a significant impact on the political landscape, contributing to the rise of populist movements and the expansion of government intervention in the economy. In the United States, President Franklin Delano Roosevelt's New Deal programs aimed to provide relief to the unemployed, stimulate economic recovery, and reform the financial system. The Depression also played a role in the rise of fascism in Europe, as people sought strong leadership and solutions to economic hardship.")
          print("The Great Depression also had a lasting impact on economic policy, as governments and international organizations adopted measures to prevent future economic crises.  The Depression had a profound impact on society,  leading to widespread social unrest, changes in cultural attitudes, and a growing awareness of social inequalities.  It also led to the development of new economic theories and the establishment of new institutions to regulate the economy. ")
          print("The Great Depression was monumental in the failure of the League of Nations, as it contributed to why the international peacekeeping organisation did not possess the necessary military and economic resources to hold nations accountable for actions in violation of agreements and the League of Nations Covenant. This is the case as the Great Depression greatly restricted the amount of disposable income and the spending power of most nations, particularly states such as Great Britain and France- who were the most significant in the League and were two of the few permanent members. As a result, these nations and others were unable to support the League militarily or economically when Japan invaded Manchuria- or when Italy invaded Abyssinia- which is explained in the 'Abyssinian Crisis' section of this application.")
          print("To learn more about the Great Depression, you may refer to the Chatbot included in this application for helpful resources and MLA8 citations.")  

    
if event in ["The Manchurian Crisis"]:
          print("There were several causes, correlated variables, unique occurrences and impacts in the Manchurian Crisis of 1931-1932.  The Japanese invasion of Manchuria was a significant event in the lead-up to World War II, and had a major impact on the global political landscape. This invasion was a step further in Japan's imperial ambitions and in its disregard towards the League of Nations.  ")
          print("The Japanese invasion of Manchuria was a direct consequence of the Japanese government's expansionist policies, driven by a desire to secure resources and control key territories in East Asia.  The Japanese also saw Manchuria as a crucial source of raw materials, especially coal and iron, which were essential for their industrial growth. ")
          print("The invasion began in September 1931 when a staged explosion (referred to as a 'false flag event') on the Japanese-owned South Manchurian Railway near Mukden provided the Japanese military with a pretext for military action.  The Japanese army, under the control of the Kwantung Army, quickly seized control of Manchuria, despite the League of Nations condemnation of their actions, through the detailed Lytton Report- which was after a year of investigation under the Lytton Commission.  The Japanese military established a puppet state known as Manchukuo, with the former Qing Dynasty Emperor Puyi as its head. Japan justified its invasion by claiming that Chinese control over Manchuria was incompetent and restricting the potential of Manchuria to become a major market in the Far East. The Japanese Empire denied any imperial or pan-asianist interests in Manchuria, and stated that the nation merely wanted to help develop Manchuria into an economic power and an independent state. ")
          print("The Manchurian Crisis had far-reaching consequences. It demonstrated the League of Nations' weakness and inability to effectively enforce international law and prevent aggression, as Japan did not cooperate with any of the League of Nations' direct orders or condemnations.  It also emboldened Japan to pursue a more aggressive foreign policy, leading to further territorial expansion and eventually to the outbreak of World War II.  The invasion also deepened tensions between Japan and the Western powers, particularly the United States, which had already imposed economic sanctions against Japan. ")
          print("The Manchurian Crisis marked a turning point in international relations, highlighting the rise of Japanese militarism and the decline of the League of Nations' authority.  It also signaled the growing instability and the emergence of new power dynamics in East Asia, setting the stage for the escalating tensions and conflicts that would lead to World War II. ")
          print("To learn more about the Manchurian Crisis, you may refer to the Chatbot included in this application for helpful resources and MLA8 citations.")

    
if event in ["The Abyssinian Crisis"]:
            print("There were several causes, correlated variables, unique occurrences and impacts in the Abyssinian Crisis of 1934-1935.  The Italian invasion of Abyssinia (Ethiopia) was a significant event in the lead-up to World War II, and a major failure of the League of Nations. It demonstrated that the League could not effectively enforce international law and prevent aggression when powerful nations were involved.  ")
            print("The Italian invasion of Abyssinia was driven by Italian ambitions to expand its colonial empire and to assert its power in the Mediterranean and African regions.  Italy had been humiliated by its defeat in the First World War and felt a need to restore its international prestige and status. Moreover, it had lost to Abyssinia in a conflict at the beginning of the 20th century, similar to how Russia had lost to Japan in the Russo-Japanese War of 1904-1905. ")
            print("The invasion began in 1935 after a border incident known as the Walwal Incident, in which Italian and Abyssinian troops clashed over a disputed territory.  The Italians used this incident as a pretext to launch a full-scale invasion, despite the League of Nations condemning their actions.  ")
            print("The Abyssinian Crisis had a number of significant consequences. It further weakened the League of Nations and emboldened other aggressor nations, such as Germany and Japan, to disregard international law and pursue their own expansionist goals. The crisis also highlighted the corruption within the League of Nations, as Britain and France- who held control over the Suez Canal (the easiest path from Europe to Africa), and could have very simply restricted Italy from its invasion, instead stuck a secret deal with Benito Mussolini, in which the powers agreed to form an alliance and let Mussolini wage his war of aggression. This was due to the fact that Great Britain and France feared the new German leader, Adolf Hitler, who had left the League of Nations, and was rapidly re-arming Germany.  ")
            print("The Abyssinian Crisis is considered to be one of the major turning points that led to World War II.  It showed that the international community was unable to prevent aggression by powerful nations, and it contributed to the breakdown of the international order.  ")
            print("To learn more about the Abyssinian Crisis, you may refer to the Chatbot included in this application for helpful resources and MLA8 citations.")
    
if event in ["World War II"]:
          print("There were several causes, correlated variables, unique occurrences and impacts in World War II- the deadliest conflict in human history.  The war was a global conflict that involved most of the world's countries, including all of the great powers, eventually forming two opposing military alliances: the Allies and the Axis.  In a state of total war (meaning that nations fully committed themselves to the war effort and placed essentially all their hopes and resources on victory), directly involving more than 100 million personnel from more than 30 countries, the major participants threw their entire economic, industrial, and scientific capabilities behind the war effort, blurring the distinction between civilian and military resources. World War II was marked by 50 to 85 million fatalities, most of whom were civilians in the Soviet Union and China. Tens of millions of people died due to genocides (including the Holocaust), premeditated death from starvation, massacres, and disease. ")
          print("The major participants in World War II were the Axis powers, led by Nazi Germany, the Empire of Japan, and the Kingdom of Italy, and the Allies, originally led by the United Kingdom, the United States, the Soviet Union, the Republic of China, and later by many other countries.  ")
          print("The war began on 1 September 1939 with the invasion of Poland by Germany and the subsequent declaration of war on Germany by France and the United Kingdom. Germany had invaded Poland as Adolf Hitler, along with other conservative nationalists in Germany, believed that the land taken away from Germany as per the Treaty of Versailles was rightfully theirs and should therefore be reclaimed from Poland. Hitler named his planned invasion of Poland 'Lebensraum'. The war in Europe ended on 8 May 1945 with the unconditional surrender of Nazi Germany to the Allies.  The war in the Pacific ended on 2 September 1945 with the unconditional surrender of Japan to the Allies. ")
          print("World War II had a profound impact on the world. It led to the deaths of millions of people, the destruction of entire cities, and the displacement of millions more.  The war also led to the rise of the United States and the Soviet Union as superpowers, the emergence of new international organizations such as the United Nations- which was created from old departments of the League of Nations, and the beginning of the Cold War- between the United States and the Soviet Union- the two above mentioned global superpowers. Although the United States had economic superiority, the Soviet Union was far larger and had comparable, if not superior military strength.")
          print("To learn more about World War II, you may refer to the Chatbot included in this application for helpful resources and MLA8 citations.")
else:
          print("Invalid event. Please enter a valid historical event.")
events = [
    {
        "name": "The Great Depression",
        "description": "A severe worldwide economic depression that took place mostly during the 1930s, beginning in the United States after a major stock market crash.",
        "resources": [
            {
                "title": "Great Depression",
                "author": "Christina D. Romer and Richard H. Pells",
                "link": "https://www.britannica.com/event/Great-Depression",
                "format": "Website Article",
                "publisher": "Encyclopedia Britannica",
                "date": "23rd October 2024",
                "mla8_citation": "Romer, Christina D., and Pells, Richard H. 'Great Depression.' Encyclopedia Britannica, 23 Oct. 2024, https://www.britannica.com/event/Great-Depression."
            },
            {
                "title": "The Impact of the Depression on the League of Nations",
                "author": "Zoe Wade",
                "link": "https://www.savemyexams.com/igcse/history/cie/18/revision-notes/the-20th-century-international-relations-from-1919/to-what-extent-was-the-league-of-nations-a-success/the-impact-of-the-depression-on-the-league-of-nations/",
                "format": "Website Article",
                "publisher": "Geography Lead",
                "date": "26th July 2024",
                "mla8_citation": "Wade, Zoe. 'The Impact of the Depression on the League of Nations | Cambridge (CIE) IGCSE History Revision Notes 2018.' Save My Exams, Geography Lead, 26 June 2024, www.savemyexams.com/igcse/history/cie/18/revision-notes/the-20th-century-international-relations-from-1919/to-what-extent-was-the-league-of-nations-a-success/the-impact-of-the-depression-on-the-league-of-nations/."
            }
        ]
    },
    {
        "name": "World War II",
        "description": "A global war that lasted from 1939 to 1945. It involved the vast majority of the world's countries—including all of the great powers—eventually forming two opposing military alliances: the Allies and the Axis.",
        "resources": [
            {
                "title": "Second World War",
                "author": "National Army Museum",
                "link": "https://www.nam.ac.uk/explore/second-world-war",
                "format": "Website Article",
                "publisher": "",
                "date": "1948",
                "mla8_citation": "National Army Museum. 'Second World War | National Army Museum.' Www.nam.ac.uk, 2 Nov. 2024, www.nam.ac.uk/explore/second-world-war."
            },
            {
                "title": "World War II",
                "author": "Wikipedia",
                "link": "https://en.wikipedia.org/wiki/World_War_II",
                "format": "Website Article",
                "publisher": "Wikimedia Foundation",
                "date": "10th December 2018",
                "mla8_citation": "Wikipedia. 'World War II.' Wikipedia, Wikimedia Foundation, 10 Dec. 2018, en.wikipedia.org/wiki/World_War_II. Accessed 2 Nov. 2024."
            }
        ]
    },
    {
        "name": "Abyssinian Crisis",
        "description": "A war of aggression waged by Italy and its dictator, Benito Mussolini, against Abyssinia (present-day Ethiopia) from 1934-1935.",
        "resources": [
            {
                "title": "Part II - The Abyssinian Crisis, 1935–1936",
                "author": "Paul G. Halpern",
                "link": "https://www.cambridge.org/core/books/abs/mediterranean-fleet-19301939/abyssinian-crisis-19351936/92237AA095F2342FBCFF5A4E39D8F013",
                "format": "Book",
                "publisher": "Cambridge University Press",
                "date": "5th March 2024",
                "mla8_citation": "G. Halpern, Paul. 'The Abyssinian Crisis, 1935–1936.' Cambridge University Press, Boydell & Brewer, 5 Mar. 2024, www.cambridge.org/core/books/abs/mediterranean-fleet-19301939/abyssinian-crisis-19351936/92237AA095F2342FBCFF5A4E39D8F013."
            },
            {
                "title": "Italo-Ethiopian War",
                "author": "The Editors of Encyclopedia",
                "link": "https://www.britannica.com/event/Italo-Ethiopian-War-1935-1936",
                "format": "Website Article",
                "publisher": "Encyclopedia Britannica",
                "date": "10th September 2024",
                "mla8_citation": "Britannica, The Editors of Encyclopaedia. 'Italo-Ethiopian War.' Encyclopedia Britannica, 10 Sep. 2024, https://www.britannica.com/event/Italo-Ethiopian-War-1935-1936."
            }
        ]
    },
    {
        "name": "Manchurian Crisis", 
        "description": "An invasion of the Manchurian region by Japan, after an initial false flag event that the Japanese Empire staged to obtain adequate reason to launch a military mobilization.",
        "resources": [
            {
                "title": "Japanese invasion of Manchuria",
                "author": "Wikipedia Contributors",
                "link": "https://en.wikipedia.org/wiki/Japanese_invasion_of_Manchuria",
                "format": "Website Article",
                "publisher": "Wikimedia Foundation",
                "date": "2nd April 2019",
                "mla8_citation": "Wikipedia Contributors. 'Japanese Invasion of Manchuria.' Wikipedia, Wikimedia Foundation, 2 Apr. 2019, en.wikipedia.org/wiki/Japanese_invasion_of_Manchuria."
            },  
            {
                "title": "Milestones: 1921–1936 - Office of the Historian",
                "author": "Office of the Historian",
                "link": "https://history.state.gov/milestones/1921-1936/mukden-incident",
                "format": "Website Article",
                "publisher": "Department of State- United States of America",
                "date": "2019",
                "mla8_citation": "Office of the Historian. 'Milestones: 1921–1936 - Office of the Historian.' State.gov, 2019, history.state.gov/milestones/1921-1936/mukden-incident."
            }
        ]
    },
    {
        "name": "World War I", 
        "description": "A war between essentially all of Europe, including the Entente powers- Britain, France, the United States, China, Russia, and Italy, and the Axis powers- Germany, Austria-Hungary, Bulgaria, and the Ottoman Empire.",
        "resources": [
            {
                "title": "World War I",
                "author": "History.com Editors",
                "link": "https://www.history.com/topics/world-war-i/world-war-i-history",
                "format": "Website Article",
                "publisher": "A&E Television Networks",
                "date": "29th October 2009",
                "mla8_citation": "History.com Editors. 'World War I.' History.com, A&E Television Networks, 29 Oct. 2009, www.history.com/topics/world-war-i/world-war-i-history."
            },
            {
                "title": "5 Things You Need To Know About The First World War",
                "author": "Imperial War Museums",
                "link": "https://www.iwm.org.uk/history/5-things-you-need-to-know-about-the-first-world-war",
                "format": "Website Article",
                "publisher": "Imperial War Museums",
                "date": "2018",
                "mla8_citation": "Imperial War Museums. '5 Things You Need to Know about the First World War.' Imperial War Museums, 2018, www.iwm.org.uk/history/5-things-you-need-to-know-about-the-first-world-war."
            }
        ]
    },
    {
        "name": "The Russo-Japanese War", 
        "description": "A war between the Russian and Japanese empires over territory in Manchuria, which was desired by both states.",
        "resources": [
            {
                "title": "The Russo-Japanese War and World History",
                "author": "John W. Steinberg",
                "link": "https://www.asianstudies.org/publications/eaa/archives/the-russo-japanese-war-and-world-history/",
                "format": "Website Article",
                "publisher": "Association for Asian Studies",
                "date": "2008",
                "mla8_citation": "Steinberg, John W. 'The Russo-Japanese War and World History.' Association for Asian Studies, 2008, www.asianstudies.org/publications/eaa/archives/the-russo-japanese-war-and-world-history/."
            },
            {
                "title": "The Russo-Japanese War: Origins and Implications",
                "author": "Benjamin Mainardi",
                "link": "https://commons.lib.jmu.edu/jmurj/vol7/iss1/1/",
                "format": "Journal Article",
                "publisher": "JMURJ",
                "date": "2nd April 2020",
                "mla8_citation": "Mainardi, Benjamin. 'The Russo-Japanese War: Origins and Implications.' James Madison Undergraduate Research Journal (JMURJ), vol. 7, no. 1, 2 Apr. 2020, commons.lib.jmu.edu/jmurj/vol7/iss1/1."
            }
        ]
    }
]
def get_resources(event_name):
    for event in events:
        if event["name"].lower() == event_name.lower():
            return event["resources"]
    return None
def chatbot():
    while True:
        user_input = input("Please ask something or type 'exit' to quit: ").strip().lower()
        if user_input == 'exit':
            break

        if user_input.startswith("give me resources and citations for"):
            event_name = user_input.replace("give me resources and citations for", "").strip()
            resources = get_resources(event_name)
            if resources:
                print(f"Resources for {event_name}:")
                for resource in resources:
                    print(f"Title: {resource['title']}")
                    print(f"Author: {resource['author']}")
                    print(f"Link: {resource['link']}")
                    print(f"MLA8 Citation: {resource['mla8_citation']}")
                    print()
            else:
                print(f"Sorry, no resources found for {event_name}.")
        else:
            print("I'm sorry, I can only provide resources and citations for events. Please try asking with 'give me resources and citations for' followed by the event name.")
# Start the chatbot
chatbot()
                    
              